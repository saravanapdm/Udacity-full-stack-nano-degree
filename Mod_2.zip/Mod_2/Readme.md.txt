This is the first project of the Full Stack Web Developer Nanodegree.

It involves writing python code to store a list of movies which will be used to generate a static web page allowing visitors to browse the movies and watch the trailers


How do I run this?

The following instructions assume you have Python installed. If not, install Python first

Step 1: Download or clone this project

Step 2: Open the terminal or command prompt

Step 3: Change the present working directory to the downloaded project folder. This can be done by entering the following command (make sure to change the path to where the project was downloaded).

cd path/to/project

Step 4: Run the following command

python entertainment_center.py
